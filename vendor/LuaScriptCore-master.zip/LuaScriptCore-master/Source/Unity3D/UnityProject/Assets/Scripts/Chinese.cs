﻿using System;

namespace AssemblyCSharp
{
	public class Chinese : Person
	{
		public Chinese ()
		{
			
		}
	}
}

