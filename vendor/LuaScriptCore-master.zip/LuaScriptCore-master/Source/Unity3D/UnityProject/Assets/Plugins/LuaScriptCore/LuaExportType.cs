﻿using System;

namespace cn.vimfung.luascriptcore
{
	/// <summary>
	/// 导出类型
	/// </summary>
	public interface LuaExportType
	{
		
	}
}

