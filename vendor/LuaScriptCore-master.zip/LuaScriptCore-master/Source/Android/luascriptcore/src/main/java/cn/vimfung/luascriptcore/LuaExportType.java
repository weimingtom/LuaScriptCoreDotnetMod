package cn.vimfung.luascriptcore;

/**
 * 导出类型
 * Created by vimfung on 2017/9/16.
 */
public interface LuaExportType
{

}
