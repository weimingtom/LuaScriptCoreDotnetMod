function test()

    local value = 256;
    return value * 4, 1111, 'Hello';

end

return test();
