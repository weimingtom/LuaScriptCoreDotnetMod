//
//  Env.h
//  LuaScriptCore
//
//  Created by 冯鸿杰 on 2017/5/9.
//  Copyright © 2017年 vimfung. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LuaScriptCore.h"

@interface Env : NSObject

+ (LSCContext *)defaultContext;

@end
