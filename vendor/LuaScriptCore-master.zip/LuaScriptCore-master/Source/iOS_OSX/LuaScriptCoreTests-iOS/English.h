//
//  English.h
//  LuaScriptCore
//
//  Created by 冯鸿杰 on 2017/5/18.
//  Copyright © 2017年 vimfung. All rights reserved.
//

#import "Person.h"

@interface English : Person

@end
