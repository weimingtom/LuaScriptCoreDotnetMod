//
//  LuaExportPropertyDescriptor.swift
//  LuaScriptCore
//
//  Created by 冯鸿杰 on 2017/12/6.
//  Copyright © 2017年 vimfung. All rights reserved.
//

/// 导出属性描述
public typealias LuaExportPropertyDescriptor = LSCExportPropertyDescriptor;
