//
//  LuaExportTypeDescriptor.swift
//  LuaScriptCore
//
//  Created by 冯鸿杰 on 2017/12/6.
//  Copyright © 2017年 vimfung. All rights reserved.
//

/// 类型描述
public typealias LuaExportTypeDescriptor = LSCExportTypeDescriptor;
