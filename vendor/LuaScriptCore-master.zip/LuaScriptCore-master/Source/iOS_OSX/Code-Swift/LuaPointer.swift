//
//  LuaPointer.swift
//  LuaScriptCore
//
//  Created by 冯鸿杰 on 16/11/30.
//  Copyright © 2016年 vimfung. All rights reserved.
//

public typealias LuaPointer = LSCPointer;
