//
//  LuaRunScriptConfig.swift
//  LuaScriptCore
//
//  Created by 冯鸿杰 on 2019/3/12.
//  Copyright © 2019年 vimfung. All rights reserved.
//

public typealias LuaScriptController = LSCScriptController;
