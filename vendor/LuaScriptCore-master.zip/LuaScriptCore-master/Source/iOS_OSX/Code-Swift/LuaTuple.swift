//
//  LuaTuple.swift
//  LuaScriptCore
//
//  Created by 冯鸿杰 on 17/1/19.
//  Copyright © 2017年 vimfung. All rights reserved.
//

public typealias LuaTuple = LSCTuple;
