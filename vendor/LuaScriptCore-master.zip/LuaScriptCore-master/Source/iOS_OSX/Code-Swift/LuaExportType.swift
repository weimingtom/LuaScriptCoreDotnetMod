//
//  LuaExportType.swift
//  LuaScriptCore
//
//  Created by 冯鸿杰 on 2017/9/8.
//  Copyright © 2017年 vimfung. All rights reserved.
//

/// 导出类型协议，实现此协议的对象表示为导出类型，可以在Lua中使用。
public typealias LuaExportType = LSCExportType;
