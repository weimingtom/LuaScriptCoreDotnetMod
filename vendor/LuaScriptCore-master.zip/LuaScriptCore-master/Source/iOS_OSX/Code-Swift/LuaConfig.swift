//
//  LuaConfig.swift
//  LuaScriptCore
//
//  Created by 冯鸿杰 on 2019/4/4.
//  Copyright © 2019年 vimfung. All rights reserved.
//

public typealias LuaConfig = LSCConfig;
