package cn.vimfung.luascriptcore.sample;

import android.util.Log;

/**
 * Created by vimfung on 2017/5/17.
 */

public class English extends Person
{
    public void speakEnglish()
    {
        Log.v("lsc", "Hello");
    }
}
