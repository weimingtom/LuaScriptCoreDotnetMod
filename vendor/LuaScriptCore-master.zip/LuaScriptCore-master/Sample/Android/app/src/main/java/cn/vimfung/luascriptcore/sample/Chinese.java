package cn.vimfung.luascriptcore.sample;

import android.util.Log;

/**
 * Created by vimfung on 17/1/19.
 */
public class Chinese extends Person
{
    public void speakChinese()
    {
        Log.v("lsc", "你好");
    }

}
