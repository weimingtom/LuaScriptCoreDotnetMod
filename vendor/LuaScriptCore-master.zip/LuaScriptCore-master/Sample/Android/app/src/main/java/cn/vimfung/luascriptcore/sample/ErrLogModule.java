package cn.vimfung.luascriptcore.sample;

import android.util.Log;

public class ErrLogModule extends LogModule
{

}
