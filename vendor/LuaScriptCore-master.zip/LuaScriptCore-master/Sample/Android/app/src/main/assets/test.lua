--
-- Created by IntelliJ IDEA.
-- User: vimfung
-- Date: 2018/1/31
-- Time: 上午9:27
-- To change this template use File | Settings | File Templates.
--

for i = 1, 10 do
    print('-------- run', i);
    Person.action(TestObjectProxy.testObj("aaa"));
end


