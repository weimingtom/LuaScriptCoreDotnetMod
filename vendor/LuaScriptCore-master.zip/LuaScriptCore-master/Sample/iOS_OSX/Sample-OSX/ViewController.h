//
//  ViewController.h
//  Sample-OSX
//
//  Created by vimfung on 16/8/22.
//  Copyright © 2016年 vimfung. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController


@end

