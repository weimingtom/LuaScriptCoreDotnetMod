//
//  ModulesViewController.h
//  Sample-OSX
//
//  Created by 冯鸿杰 on 2018/8/21.
//  Copyright © 2018年 vimfung. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ModulesViewController : NSViewController

@end
