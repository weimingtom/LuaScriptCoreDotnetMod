//
//  ModuleListViewController.swift
//  Sample-iOS-Swift
//
//  Created by 冯鸿杰 on 2018/8/21.
//  Copyright © 2018年 vimfung. All rights reserved.
//

import UIKit

class ModuleListViewController: UITableViewController
{
    @IBAction func close(_ sender: Any)
    {
        dismiss(animated: true, completion: nil);
    }
    
}
