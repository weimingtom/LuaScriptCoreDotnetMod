//
//  ViewController.h
//  Sample
//
//  Created by vimfung on 16/7/15.
//  Copyright © 2016年 vimfung. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

